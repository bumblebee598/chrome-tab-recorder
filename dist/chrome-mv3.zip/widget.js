var widget=(function(){function e(e){return e==null||typeof e==`function`?{main:e}:e}var t=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome;function n(e){let t=Math.floor(e/1e3),n=Math.floor(t/3600),r=Math.floor(t%3600/60),i=t%60,a=`${String(r).padStart(2,`0`)}:${String(i).padStart(2,`0`)}`;return n>0?`${n}:${a}`:a}var r=`__tab_recorder_widget__`,i=e(async()=>{if(document.getElementById(r))return;let e=document.createElement(`div`);e.id=r,e.style.cssText=`all: initial; position: fixed; z-index: 2147483647;`;let i=e.attachShadow({mode:`closed`});i.innerHTML=`
    <style>
      [hidden] { display: none !important; }
      .glow {
        position: fixed;
        inset: 0;
        pointer-events: none;
        box-shadow:
          inset 0 0 0 3px rgba(255, 59, 48, 0.7),
          inset 0 0 28px rgba(255, 59, 48, 0.28);
        animation: breathe 2.4s ease-in-out infinite;
      }
      .ball {
        position: fixed;
        left: 20px;
        bottom: 20px;
        width: 64px;
        height: 64px;
        border-radius: 50%;
        background: rgba(18, 18, 20, 0.88);
        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.35), 0 0 0 1px rgba(255, 255, 255, 0.1);
        display: grid;
        place-items: center;
        cursor: pointer;
        pointer-events: auto;
        transition: transform 0.15s ease;
      }
      .ball:hover { transform: scale(1.1); }
      .ball-dot {
        width: 24px;
        height: 24px;
        border-radius: 50%;
        background: #ff3b30;
        box-shadow: 0 0 0 4px rgba(255, 255, 255, 0.85);
      }
      .dismiss {
        position: absolute;
        top: -4px;
        right: -4px;
        width: 22px;
        height: 22px;
        border: none;
        border-radius: 50%;
        background: #3a3a3e;
        color: #fff;
        font: 700 13px/1 -apple-system, system-ui, sans-serif;
        cursor: pointer;
        display: none;
        place-items: center;
        padding: 0;
      }
      .ball:hover .dismiss { display: grid; }
      .pill {
        position: fixed;
        left: 20px;
        bottom: 20px;
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 14px 16px 14px 18px;
        border-radius: 999px;
        background: rgba(18, 18, 20, 0.88);
        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.35), 0 0 0 1px rgba(255, 255, 255, 0.08);
        font: 600 16px/1 -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        color: #fff;
        pointer-events: auto;
        user-select: none;
      }
      .dot {
        width: 14px;
        height: 14px;
        border-radius: 50%;
        background: #ff3b30;
        animation: blink 1.2s ease-in-out infinite;
      }
      .time {
        font-variant-numeric: tabular-nums;
        letter-spacing: 0.4px;
        min-width: 56px;
      }
      .stop {
        width: 34px;
        height: 34px;
        border: none;
        border-radius: 50%;
        background: #fff;
        cursor: pointer;
        display: grid;
        place-items: center;
        transition: transform 0.12s ease;
      }
      .stop:hover { transform: scale(1.12); }
      .stop::before {
        content: '';
        width: 13px;
        height: 13px;
        border-radius: 3px;
        background: #e02020;
      }
      .toast {
        position: fixed;
        left: 20px;
        bottom: 96px;
        max-width: 300px;
        padding: 10px 14px;
        border-radius: 10px;
        background: rgba(18, 18, 20, 0.92);
        color: #fff;
        font: 500 13px/1.4 -apple-system, system-ui, sans-serif;
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.35);
        pointer-events: none;
      }
      @keyframes blink { 50% { opacity: 0.25; } }
      @keyframes breathe {
        50% {
          box-shadow:
            inset 0 0 0 3px rgba(255, 59, 48, 0.3),
            inset 0 0 14px rgba(255, 59, 48, 0.12);
        }
      }
    </style>
    <div class="glow" hidden></div>
    <div class="ball" title="Record this tab">
      <span class="ball-dot"></span>
      <button class="dismiss" title="Hide widget">&times;</button>
    </div>
    <div class="pill" hidden title="Tab Recorder is recording this tab">
      <span class="dot"></span>
      <span class="time">00:00</span>
      <button class="stop" title="Stop recording"></button>
    </div>
    <div class="toast" hidden></div>
  `,document.documentElement.appendChild(e);let a=i.querySelector(`.glow`),o=i.querySelector(`.ball`),s=i.querySelector(`.pill`),c=i.querySelector(`.time`),l=i.querySelector(`.toast`),u=null,d=null;function f(e){o.hidden=!0,s.hidden=!1,a.hidden=!1,u&&clearInterval(u);let t=()=>{c.textContent=n(Date.now()-e)};t(),u=setInterval(t,500)}function p(){u&&clearInterval(u),u=null,s.hidden=!0,a.hidden=!0,o.hidden=!1}function m(e){l.textContent=e,l.hidden=!1,d&&clearTimeout(d),d=setTimeout(()=>{l.hidden=!0},3500)}o.addEventListener(`click`,async()=>{let e=await t.runtime.sendMessage({target:`background`,type:`START_FROM_WIDGET`}).catch(e=>({ok:!1,error:String(e)}));e?.ok||m(e?.error??`Could not start — open the extension popup to record.`)}),i.querySelector(`.dismiss`).addEventListener(`click`,t=>{t.stopPropagation(),e.remove()}),i.querySelector(`.stop`).addEventListener(`click`,()=>{t.runtime.sendMessage({target:`background`,type:`STOP_RECORDING`})}),t.runtime.onMessage.addListener(e=>{let t=e;t?.target===`widget`&&t.type===`STATE`&&(t.recording?f(t.startedAt??Date.now()):p())});let h=await t.runtime.sendMessage({target:`background`,type:`GET_REC_STATE`}).catch(()=>null);h?.isRecordingThisTab&&h.recState?f(h.recState.startedAt):p()}),a={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(()=>{let e;try{e=i.main(),e instanceof Promise&&(e=e.catch(e=>{throw a.error(`The unlisted script "widget" crashed on startup!`,e),e}))}catch(e){throw a.error(`The unlisted script "widget" crashed on startup!`,e),e}return e})()})();
widget;